<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Keuangan extends CI_Controller
{


	public function __construct()
	{
		parent::__construct();
		$this->load->model('Baseben_Model', 'baseben');

		if(empty($this->session->userdata('login'))){
			redirect(base_url());
		}
		
	}

	public function index()
	{
        $data['title'] = 'Data Keuangan';
		$data['menu'] = 'keuangan';
        $data['content'] = 'keuangan';
		$data['js'] = 'js_keuangan';
		$data['css'] = 'css_keuangan';
        $this->load->view('template/main', $data);
		
	}

	function getKeuangan(){
		$data_post = $this->input->post();

        $con = array(
            'table_name' => 'tbl_keuangan',
			'order_by' => array('id_keuangan', 'DESC')
        );

        $where = array();

        if(!empty($data_post['jenis'])){
            $where['jenis'] =  $data_post['jenis'];
        }

		if(!empty($data_post['id_keuangan'])){
            $where['id_keuangan'] =  $data_post['id_keuangan'];
        }

        if(!empty($data_post['status'])){
            $where['status'] = $data_post['status'];
        }else{
			$where['status !='] =  'Deleted';
		}

		if(!empty($data_post['tgl_awal'])){
			$where['tgl >='] = $data_post['tgl_awal'];
			$where['tgl <='] = $data_post['tgl_akhir'];
		}

        if(count($where) > 0){
            $con['where'] = $where;
        }

        $get = $this->baseben->get($con);

        foreach ($get as $k => $v) {
            $get[$k]['no'] = $k+1;
			$get[$k]['tanggal'] = hari_tgl_indo($v['tgl']);
			$get[$k]['rp'] = rupiah($v['jumlah']);

			$get[$k]['jenis_keuangan'] = $v['jenis'] == 'masuk' ? 'Pemasukan' : 'Pengeluaran';
        }

        echo json_encode(array('data' => $get));
	}

	function crud_keuangan(){
		$data_post = $this->input->post();

		$data = array(
			'table_name' => 'tbl_keuangan',
			'jenis' => $data_post['jenis'],
			'tgl' => $data_post['tgl'],
			'jumlah' => $data_post['jumlah'],
			'tujuan' => $data_post['tujuan'],
			'status' => 'Aktif'
		);

		if(!empty($data_post['id_keuangan'])){
			$data['key_name'] = 'id_keuangan';
			$data['key'] = $data_post['id_keuangan'];
			$data['updatedon'] = date('Y-m-d H:i:s');
			$data['updatedby'] = $this->session->userdata('username');
			$query = $this->baseben->update($data);
		}else{
			$data['createdon'] = date('Y-m-d H:i:s');
			$data['createdby'] = $this->session->userdata('email');

			$query = $this->baseben->insert($data);
		}

		if ($query) {
			$this->session->set_flashdata('alert', 'success');
			$this->session->set_flashdata('message', 'Data berhasil disimpan');
		} else {
			$this->session->set_flashdata('alert', 'error');
			$this->session->set_flashdata('message', 'Data gagal disimpan');
		}

		redirect(base_url() . 'keuangan');
	}

	function rekap(){
		$data['title'] = 'Rekap Data Keuangan';
		$data['menu'] = 'rekap';
        $data['content'] = 'rekap';
		$data['js'] = 'js_rekap';
		$data['css'] = 'css_rekap';
        $this->load->view('template/main', $data);
	}

	function update_status()
    {

        $data_post = $this->input->post();

        $data = array(
            'table_name' => 'tbl_keuangan',
            'status' => $data_post['status'],
            'key' => $data_post['id_keuangan'],
            'key_name' => 'id_keuangan',
			'updatedon' => date('Y-m-d H:i:s'),
			'updatedby' => $this->session->userdata('username'),
        );

        $query = $this->baseben->update($data);

        if ($query) {
            echo json_encode(array('kode' => 200, 'keterangan' => 'Status berhasil di update'));
        } else {
            echo json_encode(array('kode' => 500, 'keterangan' => 'Status gagal di update'));
        }
    }

}
