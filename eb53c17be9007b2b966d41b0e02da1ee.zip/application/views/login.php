<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Login - Sistem Keuangan</title>
    <!-- CSS files -->
    <link href="<?= base_url() ?>assets/css/tabler.min.css" rel="stylesheet" />
    <link href="<?= base_url() ?>assets/css/tabler-flags.min.css" rel="stylesheet" />
    <link href="<?= base_url() ?>assets/css/tabler-payments.min.css" rel="stylesheet" />
    <link href="<?= base_url() ?>assets/css/tabler-vendors.min.css" rel="stylesheet" />
    <link href="<?= base_url() ?>assets/css/demo.min.css" rel="stylesheet" />
</head>

<body class=" border-top-wide border-primary d-flex flex-column">
    <div class="page page-center">
        <div class="container-tight py-4">
            <div class="text-center mb-4">
                <a href="<?=base_url()?>" class="navbar-brand navbar-brand-autodark"><img src="<?=base_url()?>public/logo/<?=logo()?>" height="36" alt=""></a>
            </div>
            <form class="card card-md" action="<?= base_url() ?>auth/check_login" method="post" autocomplete="off">
                <div class="card-body">
                    <h2 class="card-title text-center mb-2">Masuk ke Akun Anda</h2>
                    <p class="text-center mb-4">Masuk menggunakan username dan password masing-masing</p>

                    <?php if ($this->session->flashdata('alert') != '') { ?>
                        <div class="row  mb-2">
                            <div class="col-lg-12">
                                <div class="alert alert-<?= $this->session->flashdata('alert') ?> solid fade show mb-2">
                                    <svg viewBox="0 0 24 24" width="24" height="24" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round" class="mr-2">
                                        <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
                                        <line x1="12" y1="9" x2="12" y2="13"></line>
                                        <line x1="12" y1="17" x2="12.01" y2="17"></line>
                                    </svg>
                                    <?= $this->session->flashdata('message') ?>
                                </div>
                            </div>
                        </div>
                    <?php  } ?>

                    <div class="mb-3">
                        <label class="form-label">Username atau Email</label>
                        <input type="text" name="username" class="form-control" placeholder="Username atau Email">
                        <input type="hidden" name="csrf_baseben" value="<?= $this->security->get_csrf_hash() ?>">
                    </div>
                    <div class="mb-2">
                        <label class="form-label">
                            Password
                        </label>
                        <div class="input-group input-group-flat">
                            <input type="password" name="password" class="form-control" placeholder="Password" autocomplete="off">
                            <span class="input-group-text">
                                <a href="#" class="link-secondary" title="Show password" data-bs-toggle="tooltip">
                                    <!-- Download SVG icon from http://tabler-icons.io/i/eye -->
                                    <svg xmlns="http://www.w3.org/2000/svg" class="icon" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                                        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                        <circle cx="12" cy="12" r="2" />
                                        <path d="M22 12c-2.667 4.667 -6 7 -10 7s-7.333 -2.333 -10 -7c2.667 -4.667 6 -7 10 -7s7.333 2.333 10 7" />
                                    </svg>
                                </a>
                            </span>
                        </div>
                    </div>
                    <div class="form-footer">
                        <button type="submit" class="btn btn-primary w-100">Masuk Sekarang</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- Libs JS -->
    <!-- Tabler Core -->
    <script src="<?= base_url() ?>assets/js/tabler.min.js"></script>
    <script src="<?= base_url() ?>assets/js/demo.min.js"></script>
</body>

</html>