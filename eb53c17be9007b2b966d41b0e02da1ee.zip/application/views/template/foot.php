<div class="container-xl">
            <div class="row text-center align-items-center flex-row-reverse">
              <div class="col-12 col-lg-12 mt-3 mt-lg-0">
                <ul class="list-inline list-inline-dots mb-0">
                  <li class="list-inline-item">
                    Copyright &copy; <?=date('Y')?>
                    <a href="." class="link-secondary">Sistem Keuangan Kas</a>.
                    All rights reserved.
                  </li>
                  <li class="list-inline-item">
                    <a href="https://lawumedia.co.id" class="link-secondary" rel="noopener">
                      Developer by Lawumedia Indonesia
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>