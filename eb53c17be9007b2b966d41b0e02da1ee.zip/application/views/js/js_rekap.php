<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.all.min.js"></script>
<script>
    $(document).ready(function() {
        showTable();
    })

    function filter(){
        showTable();
    }

    function showTable(jenis) {

        if ($.fn.DataTable.isDataTable('#tbl_general')) {
            $("#tbl_general").dataTable().fnDestroy();
            $('#tbl_general').empty();
        }

        var table = $('#tbl_general').DataTable({
            dom: 'Brtip',
            "ajax": {
                "type": 'POST',
                "url": '<?= base_url() ?>keuangan/getKeuangan',
                "data": {
                    jenis: $('#jenis_keuangan').val(),
                    tgl_awal : $('#tgl_awal').val(),
                    tgl_akhir: $('#tgl_akhir').val(),
                    status: 'Aktif',
                    csrf_baseben: '<?= $this->security->get_csrf_hash() ?>'
                }
            },
            columns: [{
                    title: 'No',
                    data: 'no',
                },
                {
                    title: 'Jenis Keuangan',
                    data: 'jenis_keuangan',
                },
                {
                    title: 'Keterangan',
                    data: 'tujuan',

                },
                {
                    title: 'Tanggal',
                    data: 'tanggal',
                },
                {
                    title: 'Jumlah (Rp)',
                    data: 'rp',
                },

            ],
            // rowGroup: {
            //     dataSrc: 'type',
            // },
            "scrollX": true,
            "displayLength": 5
        });

    }

</script>